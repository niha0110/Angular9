import {PipeTransform, Pipe} from "@angular/core";

@Pipe({
    name: "upper"
})

export class Upper implements PipeTransform{
    transform(value: any, ...args: any[]){
        return value.toUpperCase();
    }
}